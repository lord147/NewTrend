<?php

$useragent = "xxxx";

$cookie = "xxxx";

//minimum autowithdraw
$withdraw = "0.00001000";