<?php

$UA = "xxxxxxxxxx";

$COOKIE = "xxxxxxxxxx";

$URL = "xxxxxxxxxx";

?>