<?php


//User-Agent

$user = 'xxxxxxxxxxxxxxxxxx';






//link   1️⃣

$url1 = 'https://clickscoin.com/lvl-up//home.php?BTC=0&BCH=0&BCN=1&ADA=1&DASH=0&DGB=0&DOGE=1&ETH=0&ETC=0&LSK=0&LTC=0&XMR=0&NEO=0&PPC=0&POT=0&RDD=1&XRP=0&STRAX=0&XTZ=0&TRX=0&WAVES=0&ZEC=0&EXS=0&EXG=0&PIVX=0&VTC=0&KMD=0&ZEN=0&RVN=0&BTT=1&USDT=1';

//cookie 1️⃣

$cookie1 = 'PHPSESSID=xxxxxxxxxxxxxxxxxx';



//link   2️⃣

$url2 = 'https://cryptoclaim.space/home?BTC=0&BCH=0&BCN=0&DASH=0&DGB=0&DOGE=0&ETH=0&LSK=0&LTC=1&XMR=0&NEO=0&PPC=0&POT=0&XRP=0&STRAT=0&TRX=0&WAVES=0&ZEC=0&XTZ=0&PIVX=0&ETC=0&ADA=1&KMD=0&VTC=0&ZEN=0';

//cookie 2️⃣

$cookie2 = 'PHPSESSID=xxxxxxxxxxxxxxxxxx';


//link   3️⃣

$url3 = 'https://cryptofy.club/home?ADA=1&EXG=0&BCN=1&DASH=0&DGB=0&DOGE=1&BTT=1&LSK=0<C=1&EXS=1&NEO=0&PPC=0&XTZ=1&XRP=1&RDD=1&TRX=1&WAVES=0&ZEC=';

//cookie 3️⃣
$cookie3 = 'PHPSESSID=xxxxxxxxxxxxxxxxxx';



//link  4️⃣
$url4 = 'https://cryptolovers.online/home?BTC=0&BCH=0&BCN=1&ADA=1&DASH=0&DGB=1&DOGE=1&ETH=0&ETC=0&LSK=0&LTC=0&XMR=0&NEO=0&PPC=0&POT=0&RDD=1&XRP=0&STRAX=0&XTZ=1&TRX=0&WAVES=0&ZEC=0&EXS=0&EXG=0&PIVX=0&VTC=0&KMD=0';

//cookei  4️⃣
$cookie4 = 'PHPSESSID=xxxxxxxxxxxxxxxxxx';



//link  5️⃣
$url5 = 'https://dovefaucet.xyz/home?BTC=0&BCH=0&BCN=0&ADA=1&DASH=0&DGB=1&DOGE=1&ETH=0&ETC=0&LSK=0&LTC=0&XMR=0&NEO=0&PPC=0&POT=0&RDD=1&XRP=1&STRAX=0&XTZ=1&TRX=0&WAVES=0&ZEC=0&EXS=1&EXG=0&PIVX=0&VTC=0&BTT=1&RVN=0&KMD=0&USDT=1';


//cookie  5️⃣

$cookie5 = 'PHPSESSID=xxxxxxxxxxxxxxxxxx';



//link  6️⃣

$url6 = 'https://fowcy.club/home?BTC=0&BCH=0&BCN=0&DASH=1&DGB=1&DOGE=1&ETH=0&LSK=1&LTC=1&XMR=0&NEO=1&PPC=1&POT=0&XRP=1&STRAT=0&TRX=1&WAVES=1&ZEC=1&BTT=1&XTZ=1&EXS=1&EXG=1&ZEN=1';

//cookie6️⃣

$cookie6 = 'PHPSESSID=xxxxxxxxxxxxxxxxxx';




//link  7


$url7 = 'https://claimcoins.club/home?BTC=0&BCH=0&BCN=1&ADA=0&DASH=0&DGB=0&DOGE=0&ETH=0&ETC=0&LSK=0&LTC=0&XMR=0&NEO=0&PPC=0&POT=0&RDD=0&XRP=0&STRAX=0&XTZ=0&TRX=0&WAVES=0&ZEC=0&EXS=0&EXG=0&PIVX=0&VTC=0&KMD=0&ZEN=0&RVN=0&USDT=0&BTT=1';

//cookie7

$cookie7 = 'PHPSESSID=xxxxxxxxxxxxxxxxxx';











