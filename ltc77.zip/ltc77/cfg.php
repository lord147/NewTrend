<?

$wallet = "xxxxx";
$key = "xxxxx";
$cookie = "xxxxx";