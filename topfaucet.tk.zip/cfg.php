<?php

/// Topfaucet.ga Script By EarningVines.

$uag = "Mozilla/5.0 (Linux; Android 10; Redmi Note 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.101 Mobile Safari/537.36";

$cookie = "uniqueID=EC-UserId-246196; __gads=ID=0960773aae9f80f8-22268ceeeac80002:T=1621920200:RT=1621920200:S=ALNI_Mb3lQNDQSZCrpeMtEpK4KX6U-Qq8g; PHPSESSID=b138cf97df4c10e8f3f4011e88119c6e; a=oCSx8ISNRMRGJ6EVb1lrrsH34s2NNdoc; __viCookieActive=true; _popfired=1; _popfired_expires=Invalid%20Date; token_QpUJAAAAAAAAGu98Hdz1l_lcSZ2rY60Ajjk9U1c=BAYAYL2Z3QFgvZnmgAGBAsAAIPJXD2NOUQKZ3ZLf7HEy8iwKKYLaGb1jou-d3YNb62zYwQBIMEYCIQCfzbR-sBvT36VF8r7mf0yvmC4a0bHixJSGkgrVaUUVOgIhAIYqbRyKNjFIbAcaSAHCzYiRVX-JPnq5ba-Tk175efwC; _data_html=683-1_1166-1; lastOpenAt_=1623038440465";
