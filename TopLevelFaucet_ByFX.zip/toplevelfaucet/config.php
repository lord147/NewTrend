<?php

// JANGAN MENGUBAH APAPUN SELAIN YG DIDALAM TANDA (")
// PERHATIKAN TANDA (") JANGAN SAMPAI TERHAPUS
// AGAR SCRIPT TIDAK ERROR

$user = "Masukan User-agent disini";

$cookie = "Masukan Semua Cookie Disini";

