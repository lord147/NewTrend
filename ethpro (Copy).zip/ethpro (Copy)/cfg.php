<?php

// Isi Semua Data Dibawah Dengan Benar Ya !!!
// Perhatikan Bagaimama Admin Mengisi Datanya
// Jangan Lupa Support Creator Scriptnya

$wallet = "xxxx";
