<?

$cookie='xxxxx';
$user='xxxxx';