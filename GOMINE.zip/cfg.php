<?php

$useragent = "Mozilla/5.0 (Linux; Android 8.1.0; Redmi 6A) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/71.0.3578.99 Mobile Safari/537.36";

$cookie = "__.popunder=1;PHPSESSID=1r6tt87oc9u5ddl668qhu48jm4";