<?php

#MASUKAN COOKIE SEMUA MILIK KALIAN!!!
$cfduid = "__cfduid=d121b62021dd9b25def19f127ad3e269a1589982125";
$faucetpay = "faucetpay=4n48gg37ljph6e62ouf84u95au";
$remember_me = "remember_me=297675%3A0fb52fbea9a6dcd164b424f26b18c18af06819828ae5468602920ea85f6a40fd%3A1f664d3549a4225520da7b81ea3ed89f59763a8c1a0b845554b5f2eadbf1e278";
$session_token = "session_token=0445923c1be2b0689190dec5a2559669375df3a26f4ebbed5d251e95db177653";
$visitor_unique = "sc_is_visitor_unique=rx12149426.1589988957.F363F0B6F6924F729BE808AD1901FBCF.2.2.1.1.1.1.1.1.1";

#MASUKAN DATA-DATA SEMUA MILIK KALIAN!!!
$client_seed = "naLtgknOoMEGsTnuwaoBtPQDBoHm3PD5KccyEKFH7ymG3Ep7JZDxxtjFLFNkWFjXXX";
$coin = "DOGE";
$bet = "0.00000010";
$profit = "0.00000008";
$payout = "1.90000";
$chance = "50.00";
$prediction = "0";
